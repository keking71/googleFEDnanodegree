# Memory Game Project

## Table of Contents

* [Dependencies](#dependencies)
* [Instructions](#instructions)
* [Contribution](#contributing)

## Dependencies
- Font Awesome v5.2
- Google Fonts' "Coda"


## Instructions
Click cards to find matches. Upon finding all matches, the game will display your final statistics. When restarting the game, the game will shuffle the cards

## Contributing
This project is based off of starter code by Udacity.
